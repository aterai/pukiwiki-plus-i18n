(function(){
    var description = "\u5168\u90e8\u65e2\u8aad\u306b\u3057\u307e\u3059";
    var label       = "\u5168\u90e8\u65e2\u8aad\u306b\u3059\u308b";
    entry_widgets.add('test_touch_all', function(feed) {
        return [
            "<span class='button' onclick='touch_all(\"",
            feed.subscribe_id,
            "\")'>",
            label,
            "</span>"
        ].join("");
    }, description);
})();
