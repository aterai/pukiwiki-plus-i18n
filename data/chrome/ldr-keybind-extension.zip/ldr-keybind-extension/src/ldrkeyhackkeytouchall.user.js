(function() {
    Keybind.add('d', function() {
        var feed = get_active_feed(true);
        if(feed) {
            touch_all(feed.subscribe_id);
        }
    });
    Keybind.add('t', function() {
        var queue = new Queue();
        get_active_feed().items.forEach(function(item) {
            queue.push(function() {
                window.open(item.link);
            });
        });
        queue.interval = 200;
        queue.exec();
    });
    Keybind.add('q', function() {
        var logout = '/reader/logout';
        window.open(logout, '_self');
    });
}) ();
