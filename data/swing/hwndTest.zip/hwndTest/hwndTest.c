#include "windowHandler.h"
#include "jawt_md.h"
#include <windows.h>
JNIEXPORT jint JNICALL Java_windowHandler_getHWND(JNIEnv *env, jobject jobj, jobject jframe) {
    JAWT awt;
    JAWT_DrawingSurface* ds;
    JAWT_DrawingSurfaceInfo* dsi;
    JAWT_Win32DrawingSurfaceInfo* dsi_win;
    jint lock;
    HWND hWnd;
    awt.version = JAWT_VERSION_1_4;
    if (JAWT_GetAWT(env, &awt) == JNI_FALSE) {
        return 0;
    }
    ds = awt.GetDrawingSurface(env, jframe);
    if (ds == NULL) {
        return 0;
    }

    lock = ds->Lock(ds);
    if ((lock & JAWT_LOCK_ERROR) != 0) {
        awt.FreeDrawingSurface(ds);
        return 0;
    }

    dsi = ds->GetDrawingSurfaceInfo(ds);
    if (dsi == NULL) {
        ds->Unlock(ds);
        awt.FreeDrawingSurface(ds);
        return 0;
    }
    dsi_win = (JAWT_Win32DrawingSurfaceInfo*)dsi->platformInfo;
    hWnd = dsi_win->hwnd;

    /* Free the drawing surface info */
    ds->FreeDrawingSurfaceInfo(dsi);

    /* Unlock the drawing surface */
    ds->Unlock(ds);

    /* Free the drawing surface */
    awt.FreeDrawingSurface(ds);

    return (jint)hWnd;
}

/* JNIEXPORT jint JNICALL Java_windowHandler_getHWND(JNIEnv *env, jobject jc, jbyteArray class_name, jbyteArray title_name) {
 *     jbyte *cls_name = (*env)->GetByteArrayElements(env, class_name, 0);
 *     jbyte *wnd_name = (*env)->GetByteArrayElements(env, title_name, 0);
 *
 *     HWND hwnd = FindWindow(cls_name, wnd_name);
 *     CWnd* window = CWnd::FindWindow(
 *
 *     (*env)->ReleaseByteArrayElements(env, class_name, cls_name, JNI_ABORT);
 *     (*env)->ReleaseByteArrayElements(env, title_name, wnd_name, JNI_ABORT);
 *
 *     return (jint)100;
 * }
 */
