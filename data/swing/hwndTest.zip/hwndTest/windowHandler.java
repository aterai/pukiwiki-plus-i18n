import java.awt.*;
import javax.swing.*;

public class windowHandler{
    //native public static int getHWND(byte[] class_name, byte[] title_name);
    public native static int getHWND(Object obj);
    static {
        System.loadLibrary("hwndTest");
    }
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
    public static void createAndShowGUI() {
        try{
            UIManager.getInstalledLookAndFeels();
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }catch(Exception e) {
            e.printStackTrace();
        }
        final JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(320, 240);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
//         int hwnd = getHWND(
//             (frame.getClass().getName() + "\0").getBytes(),
//             (frame.getTitle() + "\0").getBytes()
//             );
        int hwnd = getHWND(frame);
        frame.setTitle("HWND: 0x"+Integer.toHexString(hwnd).toUpperCase());
    }
}
