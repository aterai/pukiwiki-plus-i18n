package example;
//-*- mode:java; Encoding:utf8n -*-
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class MainPanel extends JPanel{
    public MainPanel(final JFrame frame) {
        super();
        //System.out.println(EventQueue.isDispatchThread());
        final JDialog dialog = new JDialog(frame, "ダイアログ1", true);
        dialog.getContentPane().add(new JButton(new AbstractAction("モーダレスで開く") {
            private int count = 0;
            public void actionPerformed(ActionEvent e) {
                JDialog d = new JDialog(dialog, "ダイアログ2 - "+count, false);
                d.getContentPane().add(new JButton(new AbstractAction("dummy") {
                    public void actionPerformed(ActionEvent e) {
                        //Toolkit.getDefaultToolkit().beep();
                    }
                }), BorderLayout.NORTH);
                d.getContentPane().add(new JTextField(30), BorderLayout.SOUTH);
                d.setSize(240, 80);
                d.setLocation(240+count*40, 80+count*40);
                //d.setLocationRelativeTo(null);
                d.setVisible(true);
                count++;
            }
        }));
        dialog.setSize(240, 100);

        add(new JButton(new AbstractAction("モーダルで開く") {
            public void actionPerformed(ActionEvent e) {
                //if(dialog.isVisible()) return;
                Point p = frame.getLocation();
                dialog.setLocation(p.x+240, p.y);
                //dialog.setLocationRelativeTo(null);
                dialog.setVisible(true);
            }
        }));
        setPreferredSize(new Dimension(240, 50));
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
    public static void createAndShowGUI() {
        try{
            UIManager.getInstalledLookAndFeels();UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }catch (Exception e) {
            throw new InternalError(e.toString());
        }
        final JFrame frame = new JFrame("@title@");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.getContentPane().add(new MainPanel(frame));
        frame.pack();
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
