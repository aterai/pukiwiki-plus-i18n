package org.jdesktop.swinghelper.layer.demo;
import java.awt.*;
import java.lang.instrument.*;
import javax.swing.*;
import org.jdesktop.jxlayer.JXLayer;
import org.jdesktop.jxlayer.plaf.ext.DebugRepaintingUI;

public class DebugPainterAgent {
    public static void premain(String args) throws Exception {
        //System.out.println("premain");
        agentmain(args);
    }
    public static void agentmain(String args) throws Exception {
        System.out.println("agentmain start");
        new Thread() {
            public void run() {
                System.out.println("Thread run");
                Frame[] list = Frame.getFrames();
                while(list.length==0) {
                    try{
                        sleep(1000);
                    }catch(Exception e) {e.printStackTrace();}
                    System.out.print(".");
                    list = Frame.getFrames();
                }
                System.out.println(" ");
                System.out.println("Loop out");
                replaceLayer();
                System.out.println("Thread exit");
            }
        }.start();
        System.out.println("agentmain end");
    }
    private static void replaceLayer() {
        for(Frame f:Frame.getFrames()) {
            if(f instanceof JFrame) {
                final JFrame frame = (JFrame)f;
                EventQueue.invokeLater(new Runnable() {
                    public void run() {
                        System.out.println("replace layer");
                        JComponent c = (JComponent)frame.getContentPane();
                        JXLayer<JComponent> layer = new JXLayer<JComponent>(c);
                        layer.setUI(new DebugRepaintingUI());
                        frame.setContentPane(layer);
                        frame.pack();
                    }
                });
            }
        }
    }
}
