package example;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.imageio.*;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.*;
import java.util.logging.*;
import java.io.*;
import java.net.*;

public class MainPanel extends JPanel{
	public MainPanel() {
		super(new BorderLayout());
		ImageIcon image = new ImageIcon(getClass().getResource("test.png"));
		add(new JLabel(image), BorderLayout.CENTER);
		setPreferredSize(new Dimension(320, 240));
	}
	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}
	public static void createAndShowGUI() {
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch (Exception e) {
			throw new InternalError(e.toString());
		}
		MainPanel panel = new MainPanel();
		JFrame frame = new JFrame("�e�X�g");
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
}
